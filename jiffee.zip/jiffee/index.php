<?php
include_once('model/functions.php');
$exec = new Functions();
$log = $exec->logged_in();
	if($log == false){
		header("Location: login");
	}
?>