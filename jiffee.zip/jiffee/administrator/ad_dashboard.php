<?php
include_once('design.php');
include_once('../model/functions.php');
$exec = new Functions();
	if(isset($_GET['gccess'])){
        $ublock = $_GET['gccess'];
        $run = $exec->access_user($ublock);
        if($run == TRUE){
            echo '<span class="alert alert-success">Access Granted</span>';
        }else{
            echo '<span class="alert alert-danger">Failed, try again</span>';
        }
    }
    if(isset($_GET['block'])){
        $block = $_GET['block'];
        $run = $exec->block_user($block);
        if($run == TRUE){
            echo '<span class="alert alert-warning">User Blocked</span>';
        }else{
            echo '<span class="alert alert-danger">Failed, try again</span>';
        }
    }
    if(isset($_GET['del'])){
        $del = $_GET['del'];
        $run = $exec->delete_acc($del);
        if($run == TRUE){
            echo '<span class="alert alert-success">Account Deleted</span>';
        }else{
            echo '<span class="alert alert-danger">Failed, try again</span>';
        }
    }
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
    <link rel="stylesheet" href="../assets/font-awesome/css/font-awesome.min.css">
  <!-- CSS Files -->
  <link href="../assets/css/styles.css" rel="stylesheet" />
   <link href="css/mdb.css" rel="stylesheet" />
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="css/mdb.min.css" rel="stylesheet">
      <link href="../font-awesome/css/font-awesome.css" rel="stylesheet">
    <!-- Your custom styles (optional) -->
    <link href="css/style.min.css" rel="stylesheet">
</head>
<body>
		<!-- Styling-->
		<style>
		input{
			margin: 10px 0px;
		}
		select{
			margin: 10px 0px;
		}

		</style>

            <!-- Heading -->
            <div class="col-lg-12 card mb-4 wow fadeIn">

                <!--Card content-->
                <div class="card-body">
                    <div id="deldata"></div>
                   <!--  <form class="justify-content-center" id="help">
                         <input type="text" placeholder="Subject"  name="subject" aria-label="subject" class="form-control" required>
                        <textarea class="form-control" placeholder="Your Message" name="message"></textarea>
                         <center>    <button class="btn btn-sm my-0 p mt-3" style="background-color: purple;">
                                <i class="fa fa-paper-plane-o"></i>
                                <input type="hidden" name="send_msg">
                            </button></center>
                              
                                    
                            </form> -->
        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover" style="background-color: white; opacity: 0.8;">
                <thead class="primary">
                    <tr>
                        <td><strong>#</strong></td>
                        <td><strong><small><i class="fa fa-user"></i> Username</small></strong></td>
                        <td><strong><small><i class="fa fa-money"></i> Wallet ID</small></strong></td>
                        <td><strong><small><i class="fa fa-envelope"></i> Email</small></strong></td>
                        <td><strong><small><i class="fa fa-phone"></i> Phone_no</small></strong></td>
                        <td><strong><small><i class="fa fa-calendar"></i> Date</small></strong></td>
                        <td><strong><small><i class="fa fa-pencil"></i> Action</small></strong></td>
                        <td><strong><small><i class="fa fa-toggle-on"></i> Status</small></strong></td>
                    </tr>
                </thead>
            <tbody>
                <?php
                    $table = 'users';
                    $data = $exec->query_table($table);
                    if($data == TRUE){
                        $no     = 1;
                        $total  = 0;
                    foreach ($data as $row)
                    {
                    $amount  = $row['id'] == 0 ? '' : number_format($row['id']);
                        ?>
                    <tr>
                        <td><?php echo $no ?></td>
                        <td><?php echo $row['username']; ?></td>
                        <td><?php echo $row['wallet_id']; ?></td>
                        <td><?php echo $row['email']; ?></td>
                        <td><?php echo $row['phone']; ?></td>
                        <td><?php echo date("F j, Y - g:i:a",strtotime($row['date'])); ?></td>
                        <td style="width: 15%;">  <small><?php if($row['access'] == '0'){ echo '<span class="btn-primary btn-sm" title="unblock"><a href="ad_dashboard?gccess='.$row['id'].'" class="fa fa-unlock white-text"></a></span>'; }else if($row['access'] == '1'){echo '<span class="btn-warning btn-sm" title="block"><a href="ad_dashboard?block='.$row['id'].'" class="fa fa-lock white-text"></a></span>';} echo '<span class="btn-danger btn-sm" title="delete"><a href="ad_dashboard?del='.$row['id'].'" class="fa fa-trash white-text"></a>'?></small></td>
                        <td><?php if($row['access'] == '0'){ echo '<center><a class="fa fa-circle red-text"></a></center>'; }else if($row['access'] == '1'){echo '<center><a class="fa fa-circle green-text"></a></center>';}else{echo '';}?></td>
                    </tr>
                    <?php 
                
                    $total += $row['id'];
            $no++;
                            }
                        }else{
                            echo'<td><td><td> No records </td></td></td>';
                        }
                        
                    ?>
            </tbody>
        </table>
    </div>

                </div>

            </div>
            <script type="text/javascript">
             //    $(document).ready(function(){
             //    $('#help').submit(function(e){
             //        e.preventDefault()
             //        var datas = new FormData(this);
             //        $.ajax({
             //            url: 'fetch.php',
             //            method: 'POST',
             //            data: datas,
             //            success: function(data){
             //                $('#msg').html(data);
             //                console.log(data);
             //                // //console.log(data);
             //                // if(data === 'uploaded'){
             //                //     alert('ok')
             //                //     window.location = 'dashboard.php'
             //                // }
             //            },
             //            cache: false,
             //            contentType: false,
             //            processData: false
             //        })
             //    })
             // })
            $(document).ready(function(){
            $("#del").click(function () {
            xmlhttp = new XMLHttpRequest();
            xmlhttp.open("GET","exec.php",false);
            xmlhttp.send(null);
            document.getElementById("deldata").innerHTML=xmlhttp.responseText;
                  });
                });


          //   function dpfetcht(){
          //   xmlhttp = new XMLHttpRequest();
          //   xmlhttp.open("GET","index_img.php",false);
          //   xmlhttp.send(null);
          //   document.getElementById("avt").innerHTML=xmlhttp.responseText;

          // }
          // dpfetcht();
          // setInterval(function(){
          //   dpfetcht();
          // },2000);

            </script>

</body>
</html>