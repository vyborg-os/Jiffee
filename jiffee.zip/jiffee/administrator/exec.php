
<?php
include_once('../model/functions.php');
$exec = new Functions();
	if(isset($_GET['access'])){
		$access = $_GET['access'];
		$run = $exec->grant_access($access);
		if($run == TRUE){
			echo '<span class="alert alert-success">Access Granted</span>';
		}else{
			echo '<span class="alert alert-danger">Failed, try again</span>';
		}
	}
	if(isset($_GET['block'])){
		$block = $_GET['block'];
		$run = $exec->block_user($block);
		if($run == TRUE){
			echo '<span class="alert alert-warning">User Blocked</span>';
		}else{
			echo '<span class="alert alert-danger">Failed, try again</span>';
		}
	}
	if(isset($_GET['del'])){
		$del = $_GET['del'];
		$run = $exec->delete_acc($del);
		if($run == TRUE){
			echo '<span class="alert alert-success">Account Deleted</span>';
		}else{
			echo '<span class="alert alert-danger">Failed, try again</span>';
		}
	}
	if(isset($_POST['create'])){
		$admin_id = $exec->secure($_POST['admin_id']);
		$password = $exec->secure(md5($_POST['password']));
		$access = '1';
		$chk = $exec->get_user_ad($admin_id);
		if(empty($admin_id) || empty($password)){
			echo '<span class="alert alert-danger">All fields are mandatory</span>';
		}else if($chk == TRUE){
			echo '<span class="alert alert-danger">Username Already exist</span>';
		}else{
		$run = $exec->create_acc($admin_id,$password,$access);
		if($run == TRUE){
			echo '<span class="alert alert-success">Account created</span>';
		}else{
			echo '<span class="alert alert-danger">Failed, try again</span>';
		}
	}
	}
	?>
