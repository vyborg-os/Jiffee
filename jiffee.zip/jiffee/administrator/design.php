<?php
include_once('../home/mdblinks.html');
//include_once('top_nav.php');
session_start();
include_once('../model/functions.php');
	if(isset($_SESSION['admin_id'])){
		$session_name = $_SESSION['admin_id'];
	}else{
		header("location: login");
	}
$func = new Functions();
// $log = $func->logged_in();
//     if($log == false){
//         header("Location: login");
//     }
// if(isset($_POST['c_code'])){
// 	$codee = $_POST['c_code'];
// $f = $func->sCourse($codee);
// 						foreach ($f as $kk) {
// 							$title = $kk['title'];
// 		        			$code = $kk['code'];
// 		        			$Description = $kk['Description'];
// 		        			$type = $kk['type'];
// 		        			$unit = $kk['unit'];
//                             $session = $kk['session'];
//                             $level = $kk['level'];
// 		        		}
// 		        	}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Jiffee</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Bootstrap core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="../css/mdb.min.css" rel="stylesheet">
      <link href="../font-awesome/css/font-awesome.css" rel="stylesheet">
    <!-- Your custom styles (optional) -->
    <link href="../css/style.min.css" rel="stylesheet">
</head>

<body class="lighten-3" style="background-color: #1c2a48;">

    <!--Main Navigation-->
    <header>

        <!-- Navbar -->
        <nav class="navbar fixed-top navbar-expand-lg navbar-light scrolling-navbar" style="background-color: #0d47a1;">

            <div class="container-fluid">

                <!-- Brand -->
                <div class="navbar-wrapper">
                     <button class="navbar-toggler" style="color: white;" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="navbar-toggler-icon icon-bar"></span>
                    <span class="navbar-toggler-icon icon-bar"></span>
                    <span class="navbar-toggler-icon icon-bar"></span>
                  </button>
                <a class="navbar-brand" href="#">
                    <strong class="purple-text">Jiffee</strong>
                </a>
             
            </div>

                <!-- Collapse -->



      </div>
  </nav>
        <!-- Navbar -->

   
      <div class="sidebar" data-color="purple" data-background-color="blue" data-image="../img/sidebar-3.jpg">
      <div class="logo">
        <a class="logo-wrapper waves-effect col-sm-8" id="avtkk" style="height: 15px;"><!-- 
                <img src="../img/1.jpg" class="img-fluid" alt="" style="border-radius: 100%;"> -->
            </a>
        
      </div>
      <div class="sidebar-wrapper" style="width: 100%;">
        <ul class="nav">
            <li class="nav-item">
            <a class="nav-link" href="profile">
              <!-- <div id="avt" class="view overlay hm-zoom"></div> -->
            </a>
          </li>
            <li class="nav-item active ">
            <a class="nav-link" href="#">
              <i class="fa fa-user"></i>
              <p><?php
                        $table = 'admindb';
                        $ff = $func->query_admin($_SESSION['admin_id']);
                        foreach ($ff as $f) {
                            $user = $f['admin_id'];
                            echo '<h8>Hello '.$user.'</h8>';
                        }
                        ?></p>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="ad_dashboard">
              <i class="fa fa-dashboard"></i>
              <p>Dashboard</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="admin_page">
              <i class="fa fa-bolt"></i>
              <p>Admin</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="messages">
              <i class="fa fa-envelope-o"></i>
              <p>Messages</p>
            </a>
          </li>
             <li class="nav-item">
                 <a class="nav-link" href="logout">
                  <i class="fa fa-sign-out mr-2"></i>
                               <p>Log-out</p>
                             </a>
                            </a>
                        </li>
        </ul>
      </div>
    </div>
        <!-- Sidebar -->

    </header>
    <!--Main Navigation-->

    <!--Main layout-->
    <main class="pt-5 mx-lg-5">
        <div class="container-fluid mt-5">
    <!--/.Footer-->
 <!-- SCRIPTS -->
    <!-- JQuery -->
    <script type="text/javascript" src="../js/jquery-3.3.1.min.js"></script>
    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="../js/popper.min.js"></script>
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="../js/bootstrap.min.js"></script>
    <!-- MDB core JavaScript -->
    <script type="text/javascript" src="../js/mdb.min.js"></script>
  <script src="../assets/js/scripts.js" type="text/javascript"></script>
  <script src="../assets/js/scripts.min.js" type="text/javascript"></script>
    <!-- Initializations -->
    <script type="text/javascript">
        // Animations initialization
        new WOW().init();
        function dpfetcht(){
            xmlhttp = new XMLHttpRequest();
            xmlhttp.open("GET","index_img.php",false);
            xmlhttp.send(null);
            document.getElementById("avt").innerHTML=xmlhttp.responseText;

          }
          dpfetcht();
          setInterval(function(){
            dpfetcht();
          },2000);

    </script>
</body>
</html>