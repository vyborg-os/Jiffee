<?php
include_once('../model/functions.php');
$exec = new Functions();
$lg = $exec->logged_in();
if($lg==FALSE){
	header("Location: login");
}

?>