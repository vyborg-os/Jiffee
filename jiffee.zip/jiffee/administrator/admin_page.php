<?php
include_once('design.php');
include_once('../model/functions.php');
$exec = new Functions();
	if(isset($_GET['gccess'])){
        $ublock = $_GET['gccess'];
        $run = $exec->access_admin($ublock);
        if($run == TRUE){
            echo '<span class="alert alert-success">Access Granted</span>';
        }else{
            echo '<span class="alert alert-danger">Failed, try again</span>';
        }
    }
    if(isset($_GET['block'])){
        $block = $_GET['block'];
        $run = $exec->block_admin($block);
        if($run == TRUE){
            echo '<span class="alert alert-warning">User Blocked</span>';
        }else{
            echo '<span class="alert alert-danger">Failed, try again</span>';
        }
    }
    if(isset($_GET['del'])){
        $del = $_GET['del'];
        $run = $exec->delete_acc_ad($del);
        if($run == TRUE){
            echo '<span class="alert alert-success">Account Deleted</span>';
        }else{
            echo '<span class="alert alert-danger">Failed, try again</span>';
        }
    }
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
    <link rel="stylesheet" href="../assets/font-awesome/css/font-awesome.min.css">
  <!-- CSS Files -->
  <link href="../assets/css/styles.css" rel="stylesheet" />
   <link href="css/mdb.css" rel="stylesheet" />
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="css/mdb.min.css" rel="stylesheet">
      <link href="../font-awesome/css/font-awesome.css" rel="stylesheet">
    <!-- Your custom styles (optional) -->
    <link href="css/style.min.css" rel="stylesheet">
</head>
<body>
		<!-- Styling-->
		<style>
		input{
			margin: 10px 0px;
		}
		select{
			margin: 10px 0px;
		}

		</style>

            <!-- Heading -->
            <div class="col-lg-12 card mb-4 wow fadeIn">

                <!--Card content-->
                <div class="card-body">
                	<h6>Create Account</h6>
                    <div id="msg"></div>
                     <form class="justify-content-center" id="c_acc">
                         <input type="text" placeholder="Username"  name="admin_id" aria-label="username" class="form-control" required autocomplete="OFF">
                         <input type="text" placeholder="Password"  name="password" aria-label="password" class="form-control" required autocomplete="OFF">
                         <center>    <button class="btn btn-sm my-0 p mt-3" style="background-color: purple;">
                                <i class="fa fa-paper-plane-o"></i>
                                <input type="hidden" name="create">
                            </button></center>
                              
                                    
                            </form>
                        </div>
                    </div>
                                    
                          <!--   </form> -->
      <div class="col-lg-12 card mb-4 wow fadeIn">
      	 <div class="card-body">
       <div class="table-responsive">
            <table class="table table-responsive table-hover" style="background-color: white; opacity: 0.8;">
                <thead class="primary">
                    <tr>
                        <td><strong>#</strong></td>
                        <td><strong><small><i class="fa fa-user"></i> Admin ID</small></strong></td>
                        <td><strong><small><i class="fa fa-info"></i> Access</small></strong></td>
                        <td style="width: 20%;"><strong><small><i class="fa fa-calendar"></i> Date</small></strong></td>
                        <td><strong><small><i class="fa fa-pencil"></i> Action</small></strong></td>
                    </tr>
                </thead>
            <tbody>
                <?php
                    $table = 'admindb';
                    $data = $exec->query_table($table);
                    if($data == TRUE){
                        $no     = 1;
                        $total  = 0;
                    foreach ($data as $row)
                    {
                    $amount  = $row['a_id'] == 0 ? '' : number_format($row['a_id']);
                        ?>
                    <tr>
                        <td><small><?php echo $no ?></small></td>
                        <td><small><?php echo $row['admin_id']; ?></small></td>
                        <td><small><?php if($row['access'] == '0'){ echo '<a class="fa fa-circle red-text"></a>'; }else if($row['access'] == '1'){echo '<a class="fa fa-circle green-text"></a>';}else{echo '';}?></small></td>
                        <td><small><?php echo date("F j, Y - g:i:a",strtotime($row['date'])); ?></small></td>
                        <td><small><?php if($row['access'] == '0'){ echo '<span class="btn-primary btn-sm" title="unblock"><a href="admin_page?gaccess='.$row['a_id'].'" class="fa fa-unlock white-text"></a></span>'; }else if($row['access'] == '1'){echo '<span class="btn-warning btn-sm" title="block"><a href="admin_page?block='.$row['a_id'].'" class="fa fa-lock white-text"></a></span>';} echo '<span class="btn-danger btn-sm" title="delete"><a href="admin_page?del='.$row['a_id'].'" class="fa fa-trash white-text"></a>'?></small></td>
           
                    </tr>
                    <?php 
                
                    $total += $row['a_id'];
            $no++;
                            }
                        }else{
                            echo'<td><td><td> No records </td></td></td>';
                        }
                        
                    ?>
            </tbody>
        </table>
    </div> 
                </div>

            </div>
            <script type="text/javascript">
			    $(document).ready(function(){
			                $('#c_acc').submit(function(e){
			                    e.preventDefault()
			                    var datas = new FormData(this);
			                    $.ajax({
			                        url: 'exec.php',
			                        method: 'POST',
			                        data: datas,
			                        success: function(data){
			                            $('#msg').html(data);
			                            console.log(data);
			                            // //console.log(data);
			                            // if(data === 'uploaded'){
			                            //     alert('ok')
			                            //     window.location = 'dashboard.php'
			                            // }
			                        },
			                        cache: false,
			                        contentType: false,
			                        processData: false
			                    })
			                })
			             })
            </script>

</body>
</html>