<?php
session_start();
include_once('../model/functions.php');
$exec = new Functions();
	if(isset($_POST['login'])){
		$admin_id = $exec->secure($_POST['admin_id']);
		$password = $exec->secure(md5($_POST['password']));
		//$tbl = 'users';
			//$run = $exec->login($user,$password,$tbl);
			// if($run==TRUE){
				$getuser = $exec->query_admin($admin_id);
				if($getuser==TRUE){
				foreach($getuser as $get){
					$_SESSION['admin_id'] = $get['admin_id'];
					$access = $get['access'];
					$pw = $get['password'];
					if($access=='0'){
						$error = 'Access Denied';
					}else if($pw != $password){
						$error = 'Incorrect Password';
					}else{
						
						if(isset($_SESSION['admin_id'])){
						$session_name = $_SESSION['admin_id'];
                            header("location: ad_dashboard");
                            }else{
                            	header("location: login");
                            }
						}
					
					}
				}
			//}
					else{
						$error = 'invalid Account';
					}
				
	}
	// for($a = 0; $a < 1; $a++){
	// 	include_once("home/loader.html");
	// 	die();
	// }

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Jiffee</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="css/mdb.min.css" rel="stylesheet">
      <link href="font-awesome/css/font-awesome.css" rel="stylesheet">
    <!-- Your custom styles (optional) -->
    <link href="css/style.min.css" rel="stylesheet">

</head>
   
	<body class="lighten-3" style="background-color: #0d47a1;">
		<!-- Styling-->
		<style>
		input{
			margin: 10px 0px;
		}

		</style>
		    <main class="pt-5 mx-5">
        	<div class="container-fluid mt-5 col-lg-8 ml-4">

            <!-- Heading -->
            <div class="card mb-4 wow fadeIn">

                <!--Card content-->
                <div class="card-body">

                    <h4 class="mb-2 mb-md-0 pt-1 text-center">
                        <a href="#"><i class="fa fa-user fa-1x"></i> Admin LOGIN</a>
                       
                    </h4>
                    	 <?php
                	if(isset($error)){
                		echo '<center><span class="badge badge-danger">'.$error.'</span></center>';
                	}
                	if(isset($success)){
                		echo '<center><span class="badge badge-success">'.$success.'</span></center>';
                	}
                	?>
		                    <form class="justify-content-center" method="POST" action="<?php $_SERVER['PHP_SELF'];?>" enctype="multipart/form-data">
					 			<input type="text" placeholder="Admin ID"  name="admin_id" aria-label="admin_id" class="form-control" required autocomplete="OFF">
					 			<input type="password" placeholder="Password"  name="password" aria-label="password" class="form-control" required autocomplete="OFF">
					 			 <center> <button class="btn btn-primary btn-sm my-0 p"  name="login" type="submit">
			                            <i class="fa fa-sign-in">Login</i>
			                        </button></center>
		                    </form>
                </div>
            </div>
        </div>

            </div>
           <!-- JQuery -->
		    <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
		    <!-- Bootstrap tooltips -->
		    <script type="text/javascript" src="js/popper.min.js"></script>
		    <!-- Bootstrap core JavaScript -->
		    <script type="text/javascript" src="js/bootstrap.min.js"></script>
		    <!-- MDB core JavaScript -->
		    <script type="text/javascript" src="js/mdb.min.js"></script>
		    <!-- Initializations -->
		    <script type="text/javascript">
		        // Animations initialization
		        new WOW().init();
		    </script>

</body>
</html>