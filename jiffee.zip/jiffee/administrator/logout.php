<?php
include_once('../model/functions.php');
session_start();
session_destroy();
header("Location: login");


?>