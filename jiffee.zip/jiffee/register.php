<?php
session_start();
include_once('model/functions.php');
include_once('home/mdblinks.html');
$exec = new Functions();
	if(isset($_POST['register'])){
		$email = $exec->secure($_POST['email']);
		$username = $exec->secure($_POST['username']);
		$phone = $exec->secure($_POST['phone']);
		$pin = $exec->secure($_POST['pin']);
		$password = $exec->secure(md5($_POST['password']));
		$cpassword = $exec->secure(md5($_POST['cpassword']));
		$key = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890';
		$wallet_id = substr(str_shuffle($key), 0,9);
			if($password !== $cpassword){
				$error = 'Password does not match';
			}else if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
				$error = 'Invalid email address';
			}else if(!is_numeric($pin)){
				$error = 'Invalid Pin, Numeric only';
			}else if($exec->query_acc($phone,$email)){
				$error = 'Account already exist';
			}
			else if($exec->get_username($username) == TRUE){
				$error = 'Username already exist!';
			}
			else{
				$run = $exec->register($email,$phone,$username,$password,$wallet_id,$pin);
					if($run==TRUE){
						//send otp to phone number for authentification
						//coming soon
						//***
						$amount = 0;
						$exec->create_wallet($phone,$wallet_id,$amount);
						$key = '1234567890';
						$otp = substr(str_shuffle($key), 0,4);
						$exec->otp($phone,$otp);
						$success = 'account created successfully';
						header("Location: otp?phone=$phone");
					}else{
						$error = 'cannot create account';
						// header("Location: login");
					}
				}
		}
	
				
	
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Jiffee</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="css/mdb.min.css" rel="stylesheet">
      <link href="font-awesome/css/font-awesome.css" rel="stylesheet">
    <!-- Your custom styles (optional) -->
    <link href="css/style.min.css" rel="stylesheet">
</head>
   
	<body class="lighten-3" style="background-color: #0d47a1;">
		<!-- Styling-->
		<style>
		input{
			margin: 10px 0px;
		}

		</style>
		    <main class="pt-5 mx-5 pr-5" style="width: 80%;">
        	<div class="container-fluid mt-5">

            <!-- Heading -->
            <div class="card mb-4 wow fadeIn">

                <!--Card content-->
                <div class="card-body">

                    <h4 class="mb-2 mb-md-0 pt-1 text-center">
                        <a href="#"><i class="fa fa-user fa-1x"></i>Create Account</a>
                       
                    </h4>
                    	 <?php
                	if(isset($error)){
                		echo '<center><span class="badge badge-danger">'.$error.'</span></center>';
                	}
                	if(isset($success)){
                		echo '<center><span class="badge badge-success">'.$success.'</span></center>';
                	}
                	?>
		                    <form class="justify-content-center" method="POST" action="<?php $_SERVER['PHP_SELF'];?>" enctype="multipart/form-data" name="Ureg">
		                    	<input type="text" placeholder="Username"  name="username" aria-label="username" class="form-control" required autocomplete="OFF">
		                    	<input type="email" placeholder="Email"  name="email" aria-label="email" class="form-control" required autocomplete="OFF">
					 			<input type="text" placeholder="Mobile Number"  name="phone" aria-label="phone" class="form-control" required autocomplete="OFF">
					 			<input type="password" placeholder="Your 4 digit pin"  name="pin" aria-label="pin" class="form-control" maxlength="4" required autocomplete="OFF">
					 			<input type="password" placeholder="Password"  name="password" aria-label="password" class="form-control" required autocomplete="OFF">
					 			<input type="password" placeholder="Confirm Password"  name="cpassword" aria-label="cpassword" class="form-control" required autocomplete="OFF">
					 			<input type="checkbox" name="accept" required>Accept Terms & Condition
					 			 <center> <button class="btn btn-primary btn-sm my-0 p" onClick="validator()" name="register" type="submit">
			                            <i class="fa fa-sign-in">Register</i>
			                        </button></center>
		                    </form>
		                    <a href="login">Login</a>
                </div>
            </div>
        </div>

            </div>
           <!-- JQuery -->
		    <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
		    <!-- Bootstrap tooltips -->
		    <script type="text/javascript" src="js/popper.min.js"></script>
		    <!-- Bootstrap core JavaScript -->
		    <script type="text/javascript" src="js/bootstrap.min.js"></script>
		    <!-- MDB core JavaScript -->
		    <script type="text/javascript" src="js/mdb.min.js"></script>
		    <!-- Initializations -->
		    <script type="text/javascript">
		        // Animations initialization
		        new WOW().init();
		        function validator(){
		        	if(document.Ureg.accept.checked)
		        		console.log("ticked!");
		        	else
		        		alert("Kindly tick the box to proceed!");
		        		window.location = 'register.php';
		        }
		    </script>

</body>
</html>