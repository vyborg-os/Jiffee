<?php
session_start();
include_once('model/functions.php');
$exec = new Functions();
if(isset($_GET['phone'])){
	$phoneline = $_GET['phone'];
}else{
	echo $phoneline = '';
}
	if(isset($_POST['confirm'])){
		$phone = $phoneline;
		$otp = $exec->secure($_POST['otp']);
		if(!is_numeric($otp)){
			$error = 'invalid OTP';
		}else if(empty($otp)){
			$error = 'OTP field cannot be empty';
		}else{
			$run = $exec->fetch_otp($phone,$otp);
			if($run==TRUE){
				$table = 'users';
				$getuser = $exec->query_user($phone,$table);
				if($getuser==TRUE){
						foreach($getuser as $get){
							$_SESSION['user'] = $get['phone'];
							if(isset($_SESSION['user'])){
								$session_name = $_SESSION['user'];
								$access = '1';
								$exec->update_access($session_name,$access);
								$void = $exec->void_otp($phone);
		                            header("location: home/dashboard");
		                            }else{
		                            	header("location: otp");
		                            }
								}
						}
			}
			else{
				$error = 'Invalid/Expired OTP entered!';
			}
		}
				
	}
	if(isset($_POST['retrieve'])){
		$phone = $phoneline;
		$chk = $exec->get_phone($phone);
		if($chk==TRUE){
		$key = '123456789';
		$otp = substr(str_shuffle($key), 0,4);
		$ret = $exec->resend_otp($phone,$otp);
			if($ret==TRUE){
			$success = 'OTP resent';
			}else{
				$error = 'Error generating OTP, Try again';
			}
		}else{
			$error = 'Permission error';
		}
		
	}
	
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Jiffee</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="css/mdb.min.css" rel="stylesheet">
      <link href="font-awesome/css/font-awesome.css" rel="stylesheet">
    <!-- Your custom styles (optional) -->
    <link href="css/style.min.css" rel="stylesheet">
</head>
   
	<body class="grey lighten-3">
		<!-- Styling-->
		<style>
		input{
			margin: 10px 0px;
		}

		</style>
		    <main class="pt-5 mx-5 pr-5" style="width: 80%;">
        	<div class="container-fluid mt-5">

            <!-- Heading -->
            <div class="card mb-4 wow fadeIn">

                <!--Card content-->
                <div class="card-body">

                    <h4 class="mb-2 mb-md-0 pt-1 text-center">
                        <a href="#"><i class="fa fa-key fa-1x"></i>OTP Confirmation</a>
                       
                    </h4>
                    	 <?php
                	if(isset($error)){
                		echo '<center><span class="badge badge-danger">'.$error.'</span></center>';
                	}
                	if(isset($success)){
                		echo '<center><span class="badge badge-success">'.$success.'</span></center>';
                	}
                	?>
		                    <form class="justify-content-center" method="POST" action="<?php $_SERVER['PHP_SELF'];?>" enctype="multipart/form-data">
					 			<input type="text" placeholder="OTP"  name="otp" aria-label="otp" class="form-control" autocomplete="OFF" maxlength="4" required>
					 			 <center> <button class="btn btn-primary btn-sm my-0 p"  name="confirm" type="submit">
			                            <a>Confirm OTP</a>
			                        </button></center>
		                    </form>
		                    <form class="justify-content-center" method="POST" action="<?php $_SERVER['PHP_SELF'];?>" enctype="multipart/form-data">
		                    <input type="submit" name="retrieve" class="btn btn-default btn-sm form-control" value="Resend OTP">
		                </form>

                </div>
            </div>
        </div>
        		<div class="virtual">
        			<div class="card m5-4 ml-3" style="width: 300px; border-radius: 5%;">
        			<center><legend>Virtual Device</legend></center>
        			<small>
        				<?php
        				$phone = $phoneline;
						$virtual_phone = $exec->get_otp($phone);
						?>
						<b>New Message(<?php count($exec->get_phone($phone)); ?>)</b>
						<?php
						foreach ($virtual_phone as $key) {
							echo 'Your OTP is <b>'.$key['otp'].'</b> do not disclose, OTP remains valid for 3 minutes';
						}
						?>
					</small>
        			</div>
        		</div>
            </div>
           <!-- JQuery -->
		    <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
		    <!-- Bootstrap tooltips -->
		    <script type="text/javascript" src="js/popper.min.js"></script>
		    <!-- Bootstrap core JavaScript -->
		    <script type="text/javascript" src="js/bootstrap.min.js"></script>
		    <!-- MDB core JavaScript -->
		    <script type="text/javascript" src="js/mdb.min.js"></script>
		    <!-- Initializations -->
		    <script type="text/javascript">
		        // Animations initialization
		        new WOW().init();
		    </script>

</body>
</html>