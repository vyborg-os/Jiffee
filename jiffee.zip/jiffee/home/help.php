<?php
include_once('index.php');
include_once('../model/functions.php');
$exec = new Functions();
	
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
    <link rel="stylesheet" href="../assets/font-awesome/css/font-awesome.min.css">
  <!-- CSS Files -->
  <link href="../assets/css/styles.css" rel="stylesheet" />
   <link href="../css/mdb.css" rel="stylesheet" />
</head>
<body>
		<!-- Styling-->
		<style>
		input{
			margin: 10px 0px;
		}
		select{
			margin: 10px 0px;
		}

		</style>

            <!-- Heading -->
            <div class="col-lg-12 card mb-4 wow fadeIn">

                <!--Card content-->
                <div class="card-body">
                    <i class="fa fa-envelope-o fa-2x"></i> How can we help you?
                    <div id="msg"></div>
                    <form class="justify-content-center" id="help">
                         <input type="text" placeholder="Subject"  name="subject" aria-label="subject" class="form-control" required>
                        <textarea class="form-control" placeholder="Your Message" name="message"></textarea>
                         <center>    <button class="btn btn-sm my-0 p mt-3" style="background-color: purple;">
                                <i class="fa fa-paper-plane-o"></i>
                                <input type="hidden" name="send_msg">
                            </button></center>
                              
                                    
                            </form>

                </div>

            </div>
            <script type="text/javascript">
                $(document).ready(function(){
                $('#help').submit(function(e){
                    e.preventDefault()
                    var datas = new FormData(this);
                    $.ajax({
                        url: 'fetch.php',
                        method: 'POST',
                        data: datas,
                        success: function(data){
                            $('#msg').html(data);
                            console.log(data);
                            // //console.log(data);
                            // if(data === 'uploaded'){
                            //     alert('ok')
                            //     window.location = 'dashboard.php'
                            // }
                        },
                        cache: false,
                        contentType: false,
                        processData: false
                    })
                })
             })
            </script>

</body>
</html>