<?php
include_once('index.php');
include_once('../model/functions.php');
$exec = new Functions();
	
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
    <link rel="stylesheet" href="../assets/font-awesome/css/font-awesome.min.css">
  <!-- CSS Files -->
  <link href="../assets/css/styles.css" rel="stylesheet" />
   <link href="../css/mdb.css" rel="stylesheet" />
</head>
<body>
		<!-- Styling-->
		<style>
		input{
			margin: 10px 0px;
		}
		select{
			margin: 10px 0px;
		}

		</style>

            <!-- Heading -->
            <div class="col-lg-12 card mb-4 wow fadeIn">

                <!--Card content-->
                <div class="card-body">
                    
                                <!--Table-->
                                <table class=" table table-hover table-responsive">

                                    <!--Table head-->
                                    <thead class="mdb-color darken-3">
                                        <tr class="text-white">
                                            <th><small>Transaction ID</small></th>
                                            <th><small>Sender/Receiver</small></th>
                                            <th><small>Transaction</small></th>
                                            <th><small>Amount</small></th>
                                            <th><small>Date</small></th>
                                            <th><small>Status</small></th>
                                        </tr>
                                    </thead>

                                    <!--Table head-->

                                    <!--Table body-->
                                    <tbody>
                                    <?php
                                    $table = 'transact';
                                    $user = $session_name;
                                    $no = 1;
                                    $wallet = $exec->fetch_deff($user);
                                    foreach($wallet as $rw){
                                    $wall = $rw['wallet_id'];
                                   // echo $wall;
                                        $fetch_t = $exec->query_tt($wall);
                                    }
                                     //$fetch_t = $exec->query_t($user,$wall);
                                    
                                    foreach($fetch_t as $f){
                                        $amount = $f['amount'];
                                        $date = $f['date'];
                                        $phone = $f['phone'];
                                        $trans = $f['transaction'];
                                        $r = $f['rwallet'];
                                        $tid = $f['track_id'];
                                    
                                    ?>
                                    <tr>
                                        <!-- <td><?php echo $no++; ?></td> -->
                                        <td> <?php echo $tid; ?></td>
                                        <td><?php 
                                        if($phone == $session_name){
                                            echo 'you';
                                        }else{
                                            echo $r;
                                        }

                                        ?></td>
                                        <td><?php echo $trans; ?></td>
                                        <td><span>&#8358</span><?php echo number_format($amount); ?></td>
                                        <td><?php echo $date; ?></td>
                                        <td><center><i class="fa fa-check-circle" style="color: green;"></i></center></td>
                                    </tr>

                                        <?php
                                            }
                                        ?>
                                    </tbody>
                                    <!--Table body-->
                                </table>

                </div>

            </div>

</body>
</html>