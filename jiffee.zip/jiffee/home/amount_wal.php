<?php
include_once('../model/functions.php');
$exec = new Functions();
session_start();
 $phone = $_SESSION['user'];
                    $fetch = $exec->get_wallet_details($phone);
                      //echo ' <i class="fa fa-money fa-5x" style="color: green;"></i>';
                    foreach($fetch as $f){
                        $wall = $f['wallet_id'];
                        $amt = $f['amount'];
                        if($amt < 100){
                  echo'
                  <i class="fa fa-money fa-5x" style="color: red;"></i>
	                        <div class="col-md-12" style="color: white; font-size: 1.3em;">
	                        <span>&#8358</span>'.number_format($amt).'.00
	                        </div>';
	                       
	                        }else{ 
	                           echo'
	                           <i class="fa fa-money fa-5x" style="color: green;"></i>
	                        <div class="col-md-12" style="color: white; font-size: 1.3em;">
	                        <span>&#8358</span>'.number_format($amt).'.00
	                        </div>';
	                    }

                    }
                    

?>