<?php
include_once('../model/functions.php');
$exec = new Functions();
session_start();
 $phone = $_SESSION['user'];
 					$table = 'users';
                    $fetch = $exec->query_user($phone,$table);
                      //echo ' <i class="fa fa-money fa-5x" style="color: green;"></i>';
                    foreach($fetch as $f){
                        $img = $f['image'];
                        $img_id = $f['image_id'];
                        //$amt = $f['amount'];
                        if($img == TRUE){
		                  echo'
		                  <img src="'.$img_id.'/'.$img.'" alt="avatar"  class="rounded-circle img-responsive" style="height: 12em; width: 12em;">';
	                       
	                        }else{ 
	                           echo'
	                           <img src="../img/3.png" alt="avatar"  class="rounded-circle img-responsive" style="height: 12em; width: 12em;">';
	                    }

                    }

?>