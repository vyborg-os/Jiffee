<?php
include_once('index.php');
include_once('mdblinks.html');
include_once('../model/functions.php');
//include_once('mdblinks.html');
	$exec = new Functions();
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
      <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="../assets/font-awesome/css/font-awesome.min.css">
  <!-- CSS Files -->
  <link href="../assets/css/styles.css" rel="stylesheet" />
   <link href="../css/mdb.css" rel="stylesheet" />
</head>
<body>
		<!-- Styling-->
		<style>
		input{
			margin: 10px 0px;
		}
		select{
			margin: 10px 0px;
		}

		</style>

            <!-- Heading -->
            <div class="card mb-4 wow fadeIn">
                <!--Card content-->
                <div class="card-body">
                    <?php
                    $phone = $_SESSION['user'];
                    $fetch = $exec->get_wallet_details($phone);
                    foreach($fetch as $f){
                        $wall = $f['wallet_id'];
                        $amt = $f['amount'];
                    
                    ?>
                    <small>Wallet ID: <span class="btn-sm btn-deep-purple" style="color: #ff6d00; font-size: 1rem;">
                    <?php
                    echo $wall;
                    ?>
                    </span></small>
                </div>
            </div>
            <div class="card mb-4 wow fadeIn">

                <!--Card content-->
                <div class="card-body">
                    
                    <?php
                	if(isset($error)){
                		echo '<center><span class="badge badge-danger">'.$error.'</span></center>';
                	}
                	if(isset($success)){
                		echo '<center><span class="badge badge-success">'.$success.'</span></center>';
                	}
                	?>
                   <div class="col-lg-12">
		                <div class="car">
		                    <div class="row">
		                  <div class="col-lg-3 col-xs-16">
                            <a href="#" style="color: white;">
                                <div class="card white-text text-center" style="margin-top: 1rem; background-image: linear-gradient(orange,red);">
                                    <div class="card-body bg-blue" id="wbox" style="padding: 15px; color: black;">
                                     
                                           <!--  <?php if($amt < 100){
                                                ?>
                                            <div class="card-footer" style="color: red;">
                                            <span>&#8358</span> <?php echo number_format($amt);?>
                                            </div>
                                            <?php
                                            }else{ 
                                                ?>
                                            <div class="card-footer" style="color: green;">
                                            <span>&#8358</span> <?php echo number_format($amt);?>
                                            </div>
                                            <?php
                                            } ?> -->
                                    </div>
                                    <button class="mt-0" style="background-color: #FF8800; border-color: #FF8800;" id="fundy"><h6 class="mt-1">Fund</h6></button>
                                    <button class="mt-0" style="background-color: #FF8800; border-color: #FF8800;" id="cash"><h6 class="mt-1">Cashout</h6></button>
                                    <button class="mt-0" style="background-color: #FF8800; border-color: #FF8800;" id="sendf"><h6 class="mt-1">Send Funds</h6></button>
                                </div>
                            </a>
                            <?php 
                                }
                            ?>
                        </div>
                        <div class="cash_out col-lg-3 col-xs-6" style="display: none;">
                             <a href="#" style="color: white;">
                                <div class="card white-text text-center" style="margin-top: 1rem; background-image: linear-gradient(orange,red);">
                                    <i class="fa fa-times" id="arrowBack2" style="color: white;"></i>
                                    <div class="card-body bg-teal" style="padding: 15px;">
                                        <p style="color: white;"><i class="fa fa-bank"></i> Cashout</p>
                                        <div id="msg2" style="color: blue;"></div>
                                        <form class="justify-content-center" id="cout" method="POST" enctype="multipart/form-data">
                                            <input type="text" placeholder="Bank name"  name="bank_name" aria-label="bank_name" class="form-control" required>
                                            <input type="number" placeholder="Bank Account"  name="bank_account" aria-label="bank_account" class="form-control" required>
                                            <input type="number" placeholder="Amount"  name="amount" aria-label="amount" class="form-control" required>
                                            <input type="password" placeholder="PIN"  name="pin" aria-label="pin" class="form-control" maxlength="4" required autocomplete="OFF">
                                             <center>    <button class="btn btn-sm my-0 p" style="background-color: purple;">
                                                    <h7>Cashout</h7>
                                                    <input type="hidden" name="cashout">
                                                </button></center>
                                        </form>
                                    </div>
                                </div>
                            </a>
                            
                        </div>
                        <div class="fundz col-lg-3 col-xs-6" style="display: none;">

                            <a href="#" style="color: white;">
                                <div class="card white-text text-center" style="margin-top: 1rem; background-image: linear-gradient(orange,red);">
                                    <i class="fa fa-times" id="arrowBack" style="color: white;"></i>
                                    <div class="card-body bg-teal" style="padding: 15px;">
                                        <p style="color: white;"><i class="fa fa-credit-card"></i> Fund Wallet</p>
                                        <form>
                                            <input type="number" placeholder="Amount"  name="amount" aria-label="amount" class="form-control" required>
                                            <input type="password" placeholder="PIN"  name="pin" aria-label="pin" class="form-control" maxlength="4" required>
                                             <center> <button class="btn btn-sm my-0 p" onclick="payWithPaystack()" style="background-color: purple;">
                                                     <h7>Confirm</h7>
                                                </button></center>
                                        </form>
                                    </div>
                                </div>
                            </a>
                            
                        </div>
                              <div class="fundzz col-lg-3 col-xs-6" style="display: none;">
                            <p  style="color: white;">
                                <div class="card white-text text-center" style="margin-top: 1rem; background-image: linear-gradient(orange,red);">
                                     <i class="fa fa-times" id="arrowBack3" style="color: white;"></i>
                                    <div class="card-body bg-teal" style="padding: 15px;">
                                    	<p style="color: white;"> <i class="fa fa-eye"></i> Verify Wallet</p>
                                       <!--  <div id="msg" style="color: blue;"></div> -->
                                        <form class="justify-content-center" id="trig" method="POST" enctype="multipart/form-data">
								 			<input type="text" placeholder="Receiver's Wallet ID"  name="rwallet" aria-label="rwallet" class="form-control" required>
                                             <button class="btn-sm my-0 p" style="border-radius: 10%; background-color: purple; border-color: none; border-style: none;">
                                                    <i class="fa fa-search white-text"></i>
                                                    <input type="hidden" name="send">
                                                </button>
                                            </form>
                                    <div id="msg" style="color: blue;"></div>
                                        <form class="justify-content-center" id="trigg" method="POST" enctype="multipart/form-data">
                                            <input type="text" placeholder="Receiver Wallet ID"  name="rwallet" aria-label="wallet_id" class="form-control">
								 			<input type="text" placeholder="Description"  name="description" aria-label="description" class="form-control">
								 			<input type="number" placeholder="Amount"  name="amount" aria-label="amount" class="form-control">
								 			<input type="password" placeholder="PIN"  name="pin" aria-label="pin" class="form-control" maxlength="4">
								 			 <button class="btn btn-sm my-0 p" style="background-color: purple;">
						                             <h7>Send</h7>
                                                    <input type="hidden" name="sendfund">
						                        </button>
					                    </form>
                                    </div>
                                </div>
                            </p>
                            
                        </div>
			                    </div>
			                </div>
			            </div>
			    
                </div>

            </div>
            <script src="https://js.paystack.co/v1/inline.js"></script>

<script>
    $(document).ready(function(){
    $("#fundy").click(function () {
    $('.fundz').show();
    $('#fundy').hide();
    return false;
    });
});

    $(document).ready(function(){
    $("#arrowBack").click(function () {
    $('.fundz').hide();
    $('#fundy').show();
    return false;
    });
});
    $(document).ready(function(){
    $("#cash").click(function () {
    $('.cash_out').show();
    $('#cash').hide();
    return false;
    });
});

    $(document).ready(function(){
    $("#arrowBack2").click(function () {
    $('.cash_out').hide();
    $('#cash').show();
    return false;
    });
});
    $(document).ready(function(){
    $("#sendf").click(function () {
    $('.fundzz').show();
    $('#sendf').hide();
    return false;
    });
});

    $(document).ready(function(){
    $("#arrowBack3").click(function () {
    $('.fundzz').hide();
    $('#sendf').show();
    return false;
    });
});
   
</script>

<script>
     $(document).ready(function(){
        $('#trig').submit(function(e){
            e.preventDefault()
            var datas = new FormData(this);
            $.ajax({
                url: 'fetch.php',
                method: 'POST',
                data: datas,
                success: function(data){
                    $('#msg').html(data);
                    console.log('error log');
                    //console.log(data);
                },
                cache: false,
                contentType: false,
                processData: false
            })
        })
     })
      $(document).ready(function(){
        $('#trigg').submit(function(e){
            e.preventDefault()
            var datas = new FormData(this);
            alert('authenticate transaction');
            $.ajax({
                url: 'fetch.php',
                method: 'POST',
                data: datas,
                success: function(data){
                    $('#msg').html(data);
                    console.log('error log');
                    //console.log(data);
                },
                cache: false,
                contentType: false,
                processData: false
            })
        })
     })
     $(document).ready(function(){
        $('#cout').submit(function(e){
            e.preventDefault()
            var datas = new FormData(this);
            alert('Proceed to Cashout');
            $.ajax({
                url: 'fetch.php',
                method: 'POST',
                data: datas,
                success: function(data){
                    $('#msg2').html(data);
                        //alert('Ok');
                        //window.location = 'wallet.php'
                    // alert('Transaction Sucessful');
                    // console.log('it runs');
                    // console.log(data);
                    // window.location = 'wallet.php'
                },
                cache: false,
                contentType: false,
                processData: false
            })
        })
     })
       function wal(){
            xmlhttp = new XMLHttpRequest();
            xmlhttp.open("GET","amount_wal.php",false);
            xmlhttp.send(null);
            document.getElementById("wbox").innerHTML=xmlhttp.responseText;

          }
          wal();
          setInterval(function(){
            wal();
          },2000);
function payWithPaystack(){
    var handler = PaystackPop.setup({
      key: 'pk_test_86d32aa1nV4l1da7120ce530f0b221c3cb97cbcc',
      email: 'customer@email.com',
      amount: 10000,
      currency: "NGN",
      ref: ''+Math.floor((Math.random() * 1000000000) + 1), // generates a pseudo-unique reference. Please replace with a reference you generated. Or remove the line entirely so our API will generate one for you
      firstname: 'Stephen',
      lastname: 'King',
      // label: "Optional string that replaces customer email"
      metadata: {
         custom_fields: [
            {
                display_name: "Mobile Number",
                variable_name: "mobile_number",
                value: "+2348012345678"
            }
         ]
      },
      callback: function(response){
          alert('success. transaction ref is ' + response.reference);
      },
      onClose: function(){
          alert('window closed');
      }
    });
    handler.openIframe();
  }

</script>

</body>
</html>