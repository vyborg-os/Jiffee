<?php
include_once('../model/functions.php');
$exec = new Functions();

if(isset($_POST['send'])){
	$wallet = $exec->secure($_POST['rwallet']);
	$rr = $exec->get_wallet_id($wallet);
	if($rr == TRUE){
		foreach($rr as $r){
	
		$new = $exec->get_userid($wallet);
		foreach($new as $n){
			echo $n['username'].'<br>';
		}
			echo $r['phone'];
	}
	}else{
		echo '<span style="color: red;">No such wallet</span>';
	}
}
if(isset($_POST['cashout'])){
	session_start();
	$phone = $_SESSION['user'];
	$amount = $exec->secure($_POST['amount']);
	$bank_name = $exec->secure($_POST['bank_name']);
	$bank_account = $exec->secure($_POST['bank_account']);
	$amtt = $amount;
	$pin = $exec->secure($_POST['pin']);
	$cpin = $exec->fetch_pin($phone);
	foreach($cpin as $cp){
		$pp = $cp['pin'];
		//echo $pp;
		if($pin !== $pp){
		echo '<span style="color: red;">Invalid Pin</span>';
		}else{
			$gwal = $exec->get_wallet_details($phone);
			foreach($gwal as $gw){
				$amt = $gw['amount'];
				$trans = $gw['amount'] - $amount;
				$wid = $gw['wallet_id'];
				if($amt < $amount){
					echo '<span style="color: red;">Insufficient Funds</span>';
				}else{
						if(empty($amount) || empty($pin)){
							echo '<span style="color: red;">All fields are required</span>';
					}
					elseif (!is_numeric($amount)) {
						echo '<span style="color: red;">invalid entry, numbers only</span>';
					}else if($exec->get_amount($phone) < $amount){
						echo '<span style="color: red;">Insufficient funds</span>';
					}
					else if($amount < 200){
						echo '<span style="color: red;">Amount too low, minimum withdrawal is 200</span>';
					}
					else if($amount < 1){
						echo '<span style="color: red;">Invalid amount</span>';
					}
					else{
							$wid = $gw['wallet_id'];
							$action = '1';
							$transaction = 'You successfully withdraw <span>&#8358</span>'.number_format($amtt);
							$transs = 'You sucessfully withdraw <span>&#8358</span>'.number_format($amtt);
							$r = '1';
							$des = 'cashout';
							$rwallet = $wid;
							$exec->update_bnk($phone, $bank_name, $bank_account);
							$d = '1234567890';
							$track_id = 'JIF'.substr(str_shuffle($d),0,11);
							$sendfund = $exec->transact($phone,$rwallet,$track_id,$amtt,$des,$r,$action,$transs);
								if($sendfund==TRUE){
								// $action = '1';
								// $transaction = 'You successfully sent <span>&#8358</span>'.number_format($amtt).' to '.$rwallet;
								// $triger = $exec->update_transact($phone,$action,$transaction);
								$update_wal = $exec->update_wallet($phone,$trans);
								//5echo 'Transaction Successful';
								echo '<span style="color: green;">'.$transaction.'</span>';
									}else{
										echo '<span style="color: red;">Transaction not successful</span>';
									}
					}
				}
			}
	
		}	
	}
}
if(isset($_POST['sendfund'])){
	session_start();
	$phone = $_SESSION['user'];
	$rwallet = $exec->secure($_POST['rwallet']);
	$amount = $exec->secure($_POST['amount']);
	$amtt = $amount;
	$des = $exec->secure($_POST['description']);
	$pin = $exec->secure($_POST['pin']);
	$r = '2';
	$gwal = $exec->get_wallet_details($phone);
	$cpin = $exec->fetch_pin($phone);
	$auth_rwallet = $exec->fetch_rwallet($rwallet);
	if($auth_rwallet != TRUE){
		echo '<span style="color: red;">Invalid Wallet</span>';
	}else{
	foreach($cpin as $cp){
		$pp = $cp['pin'];
		//echo $pp;
		if($pin !== $pp){
		echo '<span style="color: red;">Invalid Pin</span>';
		}else{
			foreach($gwal as $gw){
				$amt = $gw['amount'];
				$wal_id = $gw['wallet_id'];
				$trans = $gw['amount'] - $amount;
				if($amt < $amount){
					echo '<span style="color: red;">Insufficient Funds</span>';
				}else{
						if(empty($rwallet) || empty($amount) || empty($des) || empty($pin)){
							echo '<span style="color: red;">All fields are required</span>';
					}
					elseif (!is_numeric($amount)) {
						echo '<span style="color: red;">invalid entry, numbers only</span>';
					}else if($exec->get_amount($phone) < $amount){
						echo '<span style="color: red;">Insufficient funds</span>';
					}
					else if($amount < 0 || $amount = 0){
						echo '<span style="color: red;">Invalid amount</span>';
					}
					else if($wal_id == $rwallet){
						echo '<span style="color: red;">Invalid Transaction, cannot send to oneself</span>';
					}
					else{
							$action = '1';
							$transaction = 'You successfully sent <span>&#8358</span>'.number_format($amtt).' to '.$rwallet;
							$transs = 'You sucessfully sent <span>&#8358</span>'.number_format($amtt).' to '.$rwallet;
							$d = '1234567890';
							$track_id = 'JIF'.substr(str_shuffle($d),0,11);
							$sendfund = $exec->transact($phone,$wal_id,$track_id,$amtt,$des,$r,$action,$transs);
								if($sendfund==TRUE){
									// echo '<span style="color: green;">You sucessfully sent '.number_format($amtt).' to '.$rwallet.'</span>';
									$update_wal = $exec->update_wallet($phone,$trans);
								// $action = '1';
								// $transaction = 'You successfully sent <span>&#8358</span>'.number_format($amtt).' to '.$rwallet;
								// $triger = $exec->update_transact($phone,$action,$transaction);
										if($r == 2){
											$r2 = 3;
											$amount = $exec->secure($_POST['amount']);
											$transit = 'You successfully received <span>&#8358</span>'.number_format($amount).' from '.$wal_id;
											$action2 = 1;
											$amount = $exec->secure($_POST['amount']);
											$d = '1234567890';
											$track_id = 'JIF'.substr(str_shuffle($d),0,11);
											$trans_r = $exec->transR($phone,$rwallet,$track_id,$amount,$des,$r2,$action2,$transit);
											if($trans_r == TRUE){
											$rwallet = $exec->secure($_POST['rwallet']);
											$ra = $exec->get_arw($rwallet);
											foreach($ra as $r){
												$amt_r = $r['amount'];
												$amount = $exec->secure($_POST['amount']);
												$new_amount = $amt_r + $amount;
												$rwallet = $exec->secure($_POST['rwallet']);
											$urw = $exec->update_rw($rwallet,$new_amount);
											// if($urw == TRUE){
											// 	echo '1';
											// }else{
											// 	echo '0';
											// }
												//echo $amount;
											}
											// print_r($ra);
											// $new_amount = $ra + $amount;
											// $urw = update_rw($rwallet,$new_amount);
											
											//update receiver's wallet
											// $fr = $exec->fetch_rwallet($rwallet);
											// foreach($fr as $f){
											// 	$amt = $f['amount'];
											// 	$rrr = $f['wallet_id'];
											// 	$update_amount = $amt + $amount;
											// 	$ur = $exec->update_rwallet($update_amount,$rrr);

											// }
										  }
										}
								
								echo '<span style="color: green;">'.$transaction.'</span>';
									}else{
										echo '<span style="color: red;">Transaction not successful</span>';
									}

								}
							}
						}
			
	
				}
			}
		}
	}
	if(isset($_POST['changepw'])){
	session_start();
	$phone = $_SESSION['user'];
	$oldpw = $exec->secure(md5($_POST['oldpw']));
	$npw = $exec->secure(md5($_POST['npw']));
	$cpw = $exec->secure(md5($_POST['cpw']));
	if(empty($oldpw) || empty($npw) || empty($cpw)){
		echo '<span style="color: red;">All fields are mandatory</span>';
	}else if($npw !== $cpw){
       	echo '<span style="color: red;">Password mixmatch</span>';
       }
	  else{
		$tbl = 'users';
		$run = $exec->query_user($phone,$tbl);
		if($run==TRUE){
			foreach($run as $r){
	               $pw= $r['password'];
	               if($oldpw !== $pw){
	               	echo '<span style="color: red;">Old Password not valid</span>';
	               }else if($npw==$cpw && $npw == $pw){
	               	echo '<span style="color: red;">Same password reused</span>';
	               }else{
		               	$up = $exec->update_pass($phone,$npw);
		               	if($up==TRUE){
		               		echo '<span style="color: green;">Password Updated sucessfully</span>';
		               	}else{
		               		echo '<span style="color: red;">Cannot Update Password, Try Again</span>';
		               	}
	               }
	          }
		}
	}
}
if(isset($_POST['update_img'])){
		session_start();
		$image_id = 'img/Profile'.$_SESSION['user'].'NO'.rand(0,100000000);
		$dir = mkdir($image_id);
		//$upload_dir = FULL_ROOT."../img/profile/";
		$folder = "img/".$dir."/";
		$image = $_FILES['image']['name'];
		$pictype = $_FILES['image']['type'];
		$pic_size = $_FILES['image']['size'];
		$path = $image_id.'/'.$image;
		$target = $dir.basename($_FILES['image']['name']);
		$type = pathinfo($target,PATHINFO_EXTENSION);
		$void = array('jpeg','png','jpg');
		$filename = $_FILES['image']['name'];
		$ext = pathinfo($filename, PATHINFO_EXTENSION);
		if(empty($image)){
		echo '<span style="color: red;">you have not picked any file</span>';
		}
		else if(!in_array($ext,$void)){
		echo '<span style="color: red;">Picture not allowed, only jpg,jpeg,png</span>';
		}
		// else if (file_exists($path)) {

		// }		
		else if($pic_size > 10240000 ){
		echo '<span style="color: red;">File must not exceed 1mb</span>';
		}
		else{
		$move = move_uploaded_file($_FILES['image']['tmp_name'], $path);
		$phone = $_SESSION['user'];
			$run = $exec->update_dp($image,$image_id,$phone);
			if($run==TRUE && $move==TRUE){
				echo '<span style="color: green;">Image Updated successfully</span>';
				//sleep(3);
				//header("Location: profile");
			}else{
				echo '<span style="color: red;">Error Uploading File</span>';
			}
	}
}
if(isset($_POST['send_msg'])){
	session_start();
	$phone = $_SESSION['user'];
	$subject = $exec->secure($_POST['subject']);
	$message = $exec->secure($_POST['message']);
	if(empty($subject) || empty($message)){
		echo '<span style="color: red;">All fields are mandatory</span>';
	}
	  else{
		$tbl = 'users';
		$run = $exec->query_user($phone,$tbl);
		if($run==TRUE){
			foreach($run as $r){
	               $mail= $r['email'];
		               	$sm = $exec->help_func($phone,$mail,$subject,$message);
		               	if($sm==TRUE){
		               		echo '<span class="alert alert-success pull-right">Message sent!, kindly check your mail for response</span>';
		               	}else{
		               		echo '<span class="alert alert-danger pull-right">Cannot Send Message, Try Again</span>';
		               	}
	               
	          }
		}
	}
}
		
?>
                                    