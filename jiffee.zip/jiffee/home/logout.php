<?php
session_start();
$terminate = session_destroy();
if($terminate==TRUE){
	header("Location: ../login");
	die();
}
?>