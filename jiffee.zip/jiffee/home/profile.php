<?php
include_once('index.php');
include_once('../model/functions.php');
include_once('mdblinks.html');
$exec = new Functions();

// if(isset($_POST['change'])){
// 	$phone = $session_name;
// 	$oldpw = $exec->secure(md5($_POST['old_password']));
// 	$npw = $exec->secure(md5($_POST['new_password']));
// 	$cpw = $exec->secure(md5($_POST['confirm_password']));
// 	$tbl = 'users';
// 	$run = $exec->query_user($phone,$table);
// 	if($run==TRUE){
// 		foreach($run as $r){
//                $pw= $r['password'];
//                if($oldpw !== $pw){
//                	$error = 'Old Password not valid';
//                }else if($npw !== $cpw){
//                	$error = 'Password mixmatch';
//                }else if($npw==$cpw && $npw == $pw){
//                	$error = 'Same password reused';
//                }else{
// 	               	$up = $exec->update_pass($phone,$npw);
// 	               	if($up==TRUE){
// 	               		$success = 'Password Updated sucessfully';
// 	               	}else{
// 	               		$error = 'Cannot Update Password, Try Again';
// 	               	}
//                }
//           }
// 	}
// }
	
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
		<!-- Styling-->
		<style>
		input{
			margin: 10px 0px;
		}
		select{
			margin: 10px 0px;
		}

		</style>

            <!-- Heading -->
            <div class="card mb-4 wow fadeIn">

                <!--Card content-->
                <div class="card-body">
                    
                    <?php
                	if(isset($error)){
                		echo '<center><span class="badge badge-danger">'.$error.'</span></center>';
                	}
                	if(isset($success)){
                		echo '<center><span class="badge badge-success">'.$success.'</span></center>';
                	}
                	?>
                    <span class="justify-content-center">
                               <section class="section pb-3 text-center">

    <!--Section heading-->
    <h1 class="section-heading h1 pt-1 pb-1"><i class="fa fa-user pull-center blue-text"><small>#Profile Page</small></i></h1>
    <!--Section description-->
<!--     <p class="section-description">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fugit, error amet numquam iure provident voluptate esse quasi, veritatis totam voluptas nostrum quisquam eum porro a pariatur accusamus veniam.</p> -->

    <div class="row">
    	 <!--Grid column-->
        <div class="col-lg-4 col-md-12 mb-r">

            <!--Card-->
            <div class="card testimonial-card">

                <!--Background color-->
                <div class="card-up lighten-2" style="background-color: #0d47a1; height: 3em;"><p class="mt-2 white-text">Profile</p>
                </div>

                <!--Avatar-->
                <div class="avatar" id="avtt">
                 
                </div>
                <form id="uimg">
                	<h7 id="msg"></h7>
                	<center><img src="" style="display: none;" height="50" id="img"></center>
                	<input type="file" class="form-control btn-warning btn-sm" onchange="showImage.call(this)" name="image" placeholder="Upload/Update">
                	 <button class="btn btn-primary btn-sm my-0 p">
                        <i class="fa fa-upload"></i><h7>Update</h7>
                        <input type="hidden" name="update_img">
                    </button>
                </form>

                <div class="card-body">
                    <!--Name-->
                    <?php
                        $table = 'users';
                        $ff = $func->query_user($_SESSION['user'],$table);
                        foreach ($ff as $f) {
                            $user = $f['username'];
                            $mail = $f['email'];
                            $phone = $f['phone'];

                            //echo '<h8>Hello '.$user.'</h8>';
                            echo '<small>Username:</small><h4 class="card-title mt-1">'.$user.'</h4>';
                        
                        ?>
                    
                    <hr>
                    <!--Quotation-->
                    <p><i class="fa fa-envelope"></i> <?php echo $mail;?></p>
                    <p><i class="fa fa-phone"></i><?php echo $phone;?></p>
                    <p><i class="fa fa-circle green-text"></i> active</p>
                    <?php
                }
                ?>
                </div>

            </div>
            <!--Card-->

        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-lg-4 col-md-12 mb-r">

            <!--Card-->
            <div class="card testimonial-card">

                <!--Background color-->
                <div class="card-up lighten-2" style="background-color: #0d47a1; height: 3em;"><p class="mt-2 white-text">Change Password</p>
                </div>

                <!--Avatar-->
                <div class="avatar"><i class="fa fa-key fa-3x grey-text mt-2"></i>
                </div>

                <div class="card-body">
                	<div id="pmsg">
                </div>
                    <!--Name-->
                    <!-- <h4 class="card-title mt-1">John Doe</h4>
                    <hr>
                    <p><i class="fa fa-envelope"></i> Dragon@yahoo.com</p>
                    <p><i class="fa fa-phone"></i>+234-8169421019</p>
                    <p><i class="fa fa-circle green-text"></i> active</p> -->
                    <form class="justify-content-center" method="POST" action="<?php $_SERVER['PHP_SELF'];?>" enctype="multipart/form-data" id="updatepass">
                    	<input type="password" name="oldpw" class="form-control" placeholder="Old Password" required>
                    	<input type="password" name="npw" class="form-control" placeholder="New Password" required>
                    	<input type="password" name="cpw" class="form-control" placeholder="Confirm Password" required>
                    	 <button class="btn-primary btn-sm my-0 p">
                            change
                            <input type="hidden" name="changepw">
                        </button>
                    </form>
                </div>

            </div>
            <!--Card-->

        </div>
        <!--Grid column-->

        <!--Grid column-->
				        <div class="col-lg-4 col-md-12 mb-r">

				            <!--Card-->
				            <div class="card testimonial-card">

				                <!--Background color-->
				               <div class="card-up lighten-2" style="background-color: #0d47a1; height: 3em;"><p class="mt-2 white-text">Account Details</p>
				                </div>

				                <!--Avatar-->
				                <div class="avatar"><i class="fa fa-money fa-3x grey-text mt-2"></i>
				                </div>

				                <div class="card-body">
				                    <!--Name-->
				                    <?php
				                    $phone = $session_name;
				                    $table = 'wallet';
				                    $wal = $exec->query_user($phone,$table);
				                    if($wal == TRUE){
				                    	foreach($wal as $w){
				                    		$wal_id = $w['wallet_id'];
				                    		$bn = $w['bank_name'];
				                    		$ba = $w['bank_account'];
				                    		
				                    ?>
				                   <small>Wallet ID:</small> <h4 class="card-title mt-1"><?php echo $wal_id; ?></h4>
				                    <hr>
				                    <!--Quotation-->
				                    <small>Recent Bank Used</small><p><i class="fa fa-bank"></i> <?php if($bn==TRUE){ echo $bn;}else{echo 'null';} ?></p><i class="fa fa-credit-card"></i> <?php if($ba==TRUE){ echo $ba;}else{echo 'null';} } } ?></p>
				                </div>

				            </div>
				            <!--Card-->

				        </div>
				        <!--Grid column-->

				       

				    </div>

			</section>
                                
                                    
             </span>

          </div>
        

       </div>
           <script type="text/javascript">
          $(document).ready(function(){
        $('#updatepass').submit(function(e){
            e.preventDefault()
            var datas = new FormData(this);
            $.ajax({
                url: 'fetch.php',
                method: 'POST',
                data: datas,
                success: function(data){
                    $('#pmsg').html(data);
                        //alert('Ok');
                        //window.location = 'wallet.php'
                    // alert('Transaction Sucessful');
                    // console.log('it runs');
                    // console.log(data);
                    // window.location = 'wallet.php'
                },
                cache: false,
                contentType: false,
                processData: false
            })
        })
     })
	function showImage()
	{
		if(this.files && this.files[0])
		{
			var obj = new FileReader();
			obj.onload = function(data){
				var image = document.getElementById("img");
				image.src = data.target.result;
				image.style.display = "block";
			}
			obj.readAsDataURL(this.files[0]);
		}
	}
$(document).ready(function(){
    $('#uimg').submit(function(e){
        e.preventDefault()
        var datas = new FormData(this);
        $.ajax({
            url: 'fetch.php',
            method: 'POST',
            data: datas,
            success: function(data){
                $('#msg').html(data);
                console.log(data);
                // //console.log(data);
                // if(data === 'uploaded'){
                //     alert('ok')
                //     window.location = 'dashboard.php'
                // }
            },
            cache: false,
            contentType: false,
            processData: false
        })
    })
 })
function dpfetch(){
            xmlhttp = new XMLHttpRequest();
            xmlhttp.open("GET","fetch_img.php",false);
            xmlhttp.send(null);
            document.getElementById("avtt").innerHTML=xmlhttp.responseText;

          }
          dpfetch();
          setInterval(function(){
            dpfetch();
          },2000);
</script>

</body>
</html>