<?php
include_once('datab.php');
// session_start();
class Functions{
	public $link;
	//instantiating the database
	function __construct(){
		$db = new dbcon();
		$this->link = $db->conn();
		return $this->link;
		
	}
	function secure($string){
		$sec = mysql_real_escape_string(htmlentities($string));
		return $sec;
	}
	function login($phone,$password, $table){
		$stmt = $this->link->query("SELECT * FROM ".$table." WHERE phone = '$phone' AND password = '$password'");
		$run = $stmt->fetchAll();
		return $run;
	}
	function query_table($table){
		$stmt = $this->link->prepare("SELECT * FROM ".$table);
		$stmt->execute();
		$run = $stmt->fetchAll();
		return $run;
	}
	function query_acc($phone,$email){
		$stmt = $this->link->query("SELECT * FROM users WHERE phone = '$phone' OR email = '$email'");
		$run = $stmt->fetchAll();
		return $run;
	}
	function query_user($phone,$table){
		$stmt = $this->link->query("SELECT * FROM ".$table." WHERE phone = '$phone'");
		$run = $stmt->fetchAll();
		return $run;
	}
	function query_t($phone,$wall){
		$stmt = $this->link->query("SELECT * FROM transact WHERE phone = '$phone' OR receipent = 3 AND rwallet='$wall'");
		$run = $stmt->fetchAll();
		return $run;
	}
	function query_tt($wall){
		$stmt = $this->link->query("SELECT * FROM transact WHERE rwallet='$wall' ORDER BY date desc");
		$run = $stmt->fetchAll();
		return $run;
	}
	function query_trans($user,$wall){
		$stmt = $this->link->query("SELECT * FROM transact WHERE phone = '$user' AND receipent = 2 OR receipent = 1 OR receipent = 3 AND rwallet = $wall");
		$run = $stmt->fetchAll();
		return $run;
	}
	function query_transs($rwallet,$table){
		$stmt = $this->link->query("SELECT * FROM ".$table." WHERE rwallet = '$rwallet'");
		$run = $stmt->fetchAll();
		return $run;
	}
	function register($email,$phone,$username,$password,$wallet_id,$pin){
		$stmt = $this->link->prepare("INSERT INTO users(email, phone, username, password, wallet_id, pin) VALUES(?,?,?,?,?,?)");
		$data = array($email,$phone,$username,$password,$wallet_id,$pin);
		$stmt->execute($data);
		$run = $stmt->rowCount();
		return $run;
	}
	function create_wallet($phone,$wallet_id,$amount){
		$stmt = $this->link->prepare("INSERT INTO wallet(phone,wallet_id,amount) VALUES(?,?,?)");
		$data = array($phone,$wallet_id,$amount);
		$stmt->execute($data);
		$run = $stmt->rowCount();
		return $run;
	}
	function otp($phone,$otp){
		$stmt = $this->link->prepare("INSERT INTO auth_otp(phone, otp) VALUES(?,?)");
		$data = array($phone,$otp);
		$stmt->execute($data);
		$run = $stmt->rowCount();
		return $run;
	}
	function fetch_otp($phone,$otp){
		$query = $this->link->query("SELECT * FROM auth_otp WHERE phone='$phone' AND otp='$otp'");
		$run = $query->fetchAll();
		return $run;
	}
	function get_otp($phone){
		$query = $this->link->query("SELECT * FROM auth_otp WHERE phone='$phone'");
		$run = $query->fetchAll();
		return $run;
	}
	function get_phone($phone){
		$query = $this->link->query("SELECT phone FROM auth_otp");
		$run = $query->fetchAll();
		return $run;
	}
	function get_userid($wallet_id){
		$query = $this->link->query("SELECT username FROM users WHERE wallet_id='$wallet_id'");
		$run = $query->fetchAll();
		return $run;
	}
	function get_username($username){
		$query = $this->link->query("SELECT * FROM users WHERE username='$username'");
		$chk = $query->rowCount();
		if($chk > 0){
			return true;
		}else{
			return false;
		}
		$run = $query->fetchAll();
		return $run;
	}
	function get_wallet_id($wallet_id){
		$query = $this->link->query("SELECT * FROM wallet WHERE wallet_id='$wallet_id'");
		$run = $query->fetchAll();
		return $run;
	}
	function get_wallet_details($phone){
		$query = $this->link->query("SELECT * FROM wallet WHERE phone = '$phone'");
		$run = $query->fetchAll();
		return $run;
	}
	function fetch_def($fetch,$table){
		$query = $this->link->query("SELECT wallet_id FROM wallet");
		$run = $query->fetchAll();
		return $run;
	}
	function fetch_deff($phone){
		$query = $this->link->query("SELECT wallet_id FROM wallet WHERE phone='$phone'");
		$run = $query->fetchAll();
		return $run;
	}
	function fetch_pin($phone){
		$query = $this->link->query("SELECT pin FROM users WHERE phone='$phone'");
		$run = $query->fetchAll();
		return $run;
	}
	function fetch_rwallet($wallet_id){
		$query = $this->link->query("SELECT * FROM wallet WHERE wallet_id='$wallet_id'");
		$run = $query->fetchAll();
		return $run;
	}
	function update_rwallet($amount,$wallet_id){
		$query = $this->link->query("UPDATE wallet SET amount = :amount WHERE wallet_id = :wallet_id LIMIT 1");
		$query->bindParam(':amount',$amount);
		$query->bindParam(':wallet_id',$wallet_id);
		$query->execute();
		$run = $query->rowCount();
		return $run;
	}
	function resend_otp($phone,$otp){
		$query = $this->link->prepare("UPDATE auth_otp SET otp = :otp WHERE phone = :phone LIMIT 1");
		$query->bindParam(':otp',$otp);
		$query->bindParam(':phone',$phone);
		$query->execute();
		$run = $query->rowCount();
		return $run;
	}
	function update_bnk($phone, $bank_name, $bank_account){
	$query = $this->link->prepare("UPDATE wallet SET bank_name = :bank_name, bank_account = :bank_account WHERE phone = :phone LIMIT 1");
		$query->bindParam(':bank_name',$bank_name);
		$query->bindParam(':bank_account',$bank_account);
		$query->bindParam(':phone',$phone);
		$query->execute();
		$run = $query->rowCount();
		return $run;
	}
	function void_otp($phone){
		$query = $this->link->query("DELETE FROM auth_otp WHERE phone = '$phone'");
		$run = $query->rowCount();
		return $run;
	}
	function logged_in(){
	  if (isset($_SESSION['user'])) {
	  	return true;
	  }else{
	  	return false;
	  }
	}
	function transact($phone,$rwallet,$track_id,$amount,$description,$receipent,$action,$transaction){
	$stmt = $this->link->prepare("INSERT INTO transact(phone,rwallet,track_id,amount,description,receipent,action,transaction) VALUES(?,?,?,?,?,?,?,?)");
	$data = array($phone,$rwallet,$track_id,$amount,$description,$receipent,$action,$transaction);
	$stmt->execute($data);
	$run = $stmt->rowCount();
	return $run;
	}
	function transR($phone,$rwallet,$track_id,$amount,$description,$receipent,$action,$transaction){
	$stmt = $this->link->prepare("INSERT INTO transact(phone,rwallet,track_id,amount,description,receipent,action,transaction) VALUES(?,?,?,?,?,?,?,?)");
	$data = array($phone,$rwallet,$track_id,$amount,$description,$receipent,$action,$transaction);
	$stmt->execute($data);
	$run = $stmt->rowCount();
	return $run;
	}
	function help_func($phone,$email,$subject,$message){
	$stmt = $this->link->prepare("INSERT INTO help(phone,email,subject,message) VALUES(?,?,?,?)");
	$data = array($phone,$email,$subject,$message);
	$stmt->execute($data);
	$run = $stmt->rowCount();
	return $run;
	}
	function create_acc($admin_id,$password,$access){
	$stmt = $this->link->prepare("INSERT INTO admindb(admin_id,password,access) VALUES(?,?,?)");
	$data = array($admin_id,$password,$access);
	$stmt->execute($data);
	$run = $stmt->rowCount();
	return $run;
	}
	function get_user_ad($admin_id){
		$query = $this->link->query("SELECT * FROM admindb WHERE admin_id='$admin_id'");
		$run = $query->fetchAll();
		return $run;
	}
	function get_amount($phone){
		$query = $this->link->query("SELECT amount FROM transact WHERE phone='$phone'");
		$run = $query->fetchAll();
		return $run;
	}
	function get_access_info($phone){
		$query = $this->link->query("SELECT access FROM transact WHERE phone='$phone'");
		$run = $query->fetchAll();
		return $run;
	}
	function update_transact($phone,$action,$transaction){
		$query = $this->link->prepare("UPDATE transact SET action = :action, transaction = :transaction WHERE phone = :phone LIMIT 1");
		$query->bindParam(':action',$action);
		$query->bindParam(':transaction',$transaction);
		$query->bindParam(':phone',$phone);
		$query->execute();
		$run = $query->rowCount();
		return $run;
	}
	function update_wallet($phone,$amount){
		$query = $this->link->prepare("UPDATE wallet SET amount = :amount WHERE phone = :phone LIMIT 1");
		$query->bindParam(':amount',$amount);
		$query->bindParam(':phone',$phone);
		$query->execute();
		$run = $query->rowCount();
		return $run;
	}
	function update_access($phone,$access){
		$query = $this->link->prepare("UPDATE users SET access = :access WHERE phone = :phone");
		$query->bindParam(':access',$access);
		$query->bindParam(':phone',$phone);
		$query->execute();
		$run = $query->rowCount();
		return $run;
	}
	function update_pass($phone,$npw){
		$query = $this->link->prepare("UPDATE users SET password = :npw WHERE phone = :phone");
		$query->bindParam(':npw',$npw);
		$query->bindParam(':phone',$phone);
		$query->execute();
		$run = $query->rowCount();
		return $run;
	}
	function update_rw($wallet_id,$amount){
		$query = $this->link->prepare("UPDATE wallet SET amount = :amount WHERE wallet_id = :wallet_id");
		$query->bindParam(':amount',$amount);
		$query->bindParam(':wallet_id',$wallet_id);
		$query->execute();
		$run = $query->rowCount();
		return $run;
	}
	function update_dp($image,$image_id,$phone){
		$query = $this->link->prepare("UPDATE users SET image = :image, image_id = :image_id WHERE phone = :phone");
		$query->bindParam(':image',$image);
		$query->bindParam(':image_id',$image_id);
		$query->bindParam(':phone',$phone);
		$query->execute();
		$run = $query->rowCount();
		return $run;
	}
	function get_arw($rwallet){
		$query = $this->link->query("SELECT * FROM wallet WHERE wallet_id='$rwallet'");
		$run = $query->fetchAll();
		return $run;
	}
	function query_admin($admin_id){
		$stmt = $this->link->query("SELECT * FROM admindb WHERE admin_id = '$admin_id'");
		$run = $stmt->fetchAll();
		return $run;
	}
	function access_user($ublock){
		$stmt = $this->link->query("UPDATE users SET access = '1' WHERE id = '$ublock'");
		$run = $stmt->rowCount();
		return $run;
	}
	function block_user($block){
		$stmt = $this->link->query("UPDATE users SET access = '0' WHERE id = '$block'");
		$run = $stmt->rowCount();
		return $run;
	}
	function delete_acc($del){
		$stmt = $this->link->query("DELETE FROM users WHERE id ='$del'");
		$run = $stmt->rowCount();
		return $run;
	}
	function access_admin($ublock){
		$stmt = $this->link->query("UPDATE admindb SET access = '1' WHERE a_id = '$ublock'");
		$run = $stmt->rowCount();
		return $run;
	}
	function block_admin($block){
		$stmt = $this->link->query("UPDATE admindb SET access = '0' WHERE a_id = '$block'");
		$run = $stmt->rowCount();
		return $run;
	}
	function delete_acc_ad($del){
		$stmt = $this->link->query("DELETE FROM admindb WHERE a_id ='$del'");
		$run = $stmt->rowCount();
		return $run;
	}
	function delete_wal($phone){
		$stmt = $this->link->query("DELETE FROM wallet WHERE phone ='$phone'");
		$run = $stmt->rowCount();
		return $run;
	}

	function delete_msg($archieve){
		$stmt = $this->link->query("DELETE FROM help WHERE id ='$archieve'");
		$run = $stmt->rowCount();
		return $run;
	}


}